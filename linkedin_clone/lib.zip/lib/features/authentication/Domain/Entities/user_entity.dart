class UserEntity {
  final String token;

  UserEntity({
    required this.token,  


}); 

}